This is a zip, not a vsearch UDB index.
